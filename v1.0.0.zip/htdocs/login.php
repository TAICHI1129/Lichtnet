<?php

define("SECRET_KEY","LICHTNET_SUPER_SECRET_KEY");

$msg="";
$from=$_GET["from"] ?? "";

function create_token($email){

$payload=[
"email"=>$email,
"iat"=>time(),
"exp"=>time()+60
];

$json=json_encode($payload);

$b64=base64_encode($json);

$sign=hash_hmac("sha256",$b64,SECRET_KEY);

return $b64.".".$sign;
}

if($_SERVER["REQUEST_METHOD"]==="POST"){

$email=filter_input(INPUT_POST,"email",FILTER_VALIDATE_EMAIL);
$password=$_POST["password"];

$data=json_decode(file_get_contents("account.json"),true);

foreach($data as $acc){

if($acc["email"]==$email && password_verify($password,$acc["password"])){

if($from){

$token=create_token($email);

header("Location: ".$from."?token=".urlencode($token));
exit;

}

$msg="Login success";
break;

}

}

if($msg===""){
$msg="Login failed";
}

}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="style.css">
<title>Lichtnet Login</title>
</head>

<body>

<div class="container">

<h1>Lichtnet Login</h1>

<div class="msg"><?=$msg?></div>

<form method="post">

<input name="email" type="email" placeholder="Email" required>

<input name="password" type="password" placeholder="Password" required>

<button>Login</button>

</form>

<div class="switch">
<a href="register.php">Create account</a>
</div>

</div>

</body>
</html>