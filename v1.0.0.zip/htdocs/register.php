<?php

$msg="";

if($_SERVER["REQUEST_METHOD"]==="POST"){

$email=filter_input(INPUT_POST,"email",FILTER_VALIDATE_EMAIL);
$password=$_POST["password"];

if($email && strlen($password)>=6){

$data=json_decode(file_get_contents("account.json"),true);

foreach($data as $a){
if($a["email"]==$email){
$msg="Account exists";
break;
}
}

if($msg===""){

$hash=password_hash($password,PASSWORD_DEFAULT);

$data[]=[
"email"=>$email,
"password"=>$hash
];

file_put_contents("account.json",json_encode($data,JSON_PRETTY_PRINT));

$msg="Account created";
}

}else{
$msg="Invalid input";
}

}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="style.css">
<title>Lichtnet Register</title>
</head>

<body>

<div class="container">

<h1>Create Account</h1>

<div class="msg"><?=$msg?></div>

<form method="post">

<input name="email" type="email" placeholder="Email" required>

<input name="password" type="password" placeholder="Password" required>

<button>Register</button>

</form>

<div class="switch">
<a href="login.php">Login</a>
</div>

</div>

</body>
</html>