<?php
require "db.php";

ini_set('display_errors', 1);
error_reporting(E_ALL);

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

$messages=[
"ja"=>[
"username"=>"ユーザー名",
"email"=>"メール",
"password"=>"パスワード",
"register"=>"登録",
"switch"=>"ログインはこちら"
],
"en"=>[
"username"=>"Username",
"email"=>"Email",
"password"=>"Password",
"register"=>"Register",
"switch"=>"Login"
],
"es"=>[
"username"=>"Usuario",
"email"=>"Correo",
"password"=>"Contraseña",
"register"=>"Crear cuenta",
"switch"=>"Iniciar sesión"
],
"zh"=>[
"username"=>"用户名",
"email"=>"邮箱",
"password"=>"密码",
"register"=>"创建账号",
"switch"=>"登录"
]
];

if($_SERVER["REQUEST_METHOD"]==="POST"){

$username=$_POST["username"] ?? "";
$email=$_POST["email"] ?? "";
$password=$_POST["password"] ?? "";
$from=$_POST["from"] ?? "";

$errors=[];

// ユーザー名チェック
if(strlen($username)<3){
    $errors[]="ユーザー名は3文字以上";
}

// メールチェック
if(strlen($email)==0){
    $errors[]="メール未入力";
}elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
    $errors[]="メール形式が不正";
}

// パスワードチェック
if(strlen($password)<6){
    $errors[]="パスワードは6文字以上";
}

if(empty($errors)){

$hash=password_hash($password,PASSWORD_DEFAULT);

try{
    $stmt=$pdo->prepare("INSERT INTO users(username,email,password) VALUES (?,?,?)");
    $stmt->execute([$username,$email,$hash]);

    $msg="登録成功";

}catch(PDOException $e){

    if($e->errorInfo[1] == 1062){

        if(strpos($e->getMessage(), "email") !== false){
            $msg = "このメールは既に登録されています";
        }elseif(strpos($e->getMessage(), "username") !== false){
            $msg = "このユーザー名は既に使用されています";
        }else{
            $msg = "重複エラー";
        }

    }else{
        $msg = "DBエラー: " . $e->getMessage();
    }

}

}else{
    $msg=implode("<br>",$errors);
}

}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">

<!-- 言語切替 -->
<div class="lang-select">
<form method="get">
<select name="lang" onchange="this.form.submit()">
<option value="ja" <?=$lang=="ja"?"selected":""?>>日本語</option>
<option value="en" <?=$lang=="en"?"selected":""?>>English</option>
<option value="es" <?=$lang=="es"?"selected":""?>>Español</option>
<option value="zh" <?=$lang=="zh"?"selected":""?>>中文</option>
</select>
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
</form>
</div>

<h1>Lichtnet</h1>

<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">

<input type="text" name="username" placeholder="<?=$messages[$lang]["username"]?>" required>
<input type="email" name="email" placeholder="<?=$messages[$lang]["email"]?>" required>
<input type="password" name="password" placeholder="<?=$messages[$lang]["password"]?>" required>

<button><?=$messages[$lang]["register"]?></button>
</form>

<div>
<a href="login.php?from=<?=urlencode($from)?>&lang=<?=$lang?>" class="btn">
<?=$messages[$lang]["switch"]?>
</a>
</div>

<div><?=$msg?></div>

</div>

</body>
</html>