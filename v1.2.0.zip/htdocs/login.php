<?php
require "db.php";

define("SECRET_KEY","LICHTNET_SECRET_KEY");

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

$messages=[
"ja"=>[
"email"=>"メール",
"password"=>"パスワード",
"login"=>"ログイン",
"switch"=>"アカウント作成"
],
"en"=>[
"email"=>"Email",
"password"=>"Password",
"login"=>"Login",
"switch"=>"Create account"
],
"es"=>[
"email"=>"Correo",
"password"=>"Contraseña",
"login"=>"Iniciar sesión",
"switch"=>"Crear cuenta"
],
"zh"=>[
"email"=>"邮箱",
"password"=>"密码",
"login"=>"登录",
"switch"=>"创建账号"
]
];

function create_token($email,$username){
    $payload=[
        "email"=>$email,
        "username"=>$username,
        "iat"=>time(),
        "exp"=>time()+120
    ];
    $b64=base64_encode(json_encode($payload));
    $sign=hash_hmac("sha256",$b64,SECRET_KEY);
    return $b64.".".$sign;
}

if($_SERVER["REQUEST_METHOD"]==="POST"){

$email=$_POST["email"] ?? "";
$password=$_POST["password"] ?? "";
$from=$_POST["from"] ?? "";

$stmt=$pdo->prepare("SELECT * FROM users WHERE email=?");
$stmt->execute([$email]);
$user=$stmt->fetch();

if($user && password_verify($password,$user["password"])){

if(!empty($from)){
$token=create_token($email,$user["username"]);
header("Location: ".$from."?token=".urlencode($token));
exit;
}

$msg="ログイン成功";

}else{
$msg="ログイン失敗";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">

<!-- 言語切替 -->
<div class="lang-select">
<form method="get">
<select name="lang" onchange="this.form.submit()">
<option value="ja" <?=$lang=="ja"?"selected":""?>>日本語</option>
<option value="en" <?=$lang=="en"?"selected":""?>>English</option>
<option value="es" <?=$lang=="es"?"selected":""?>>Español</option>
<option value="zh" <?=$lang=="zh"?"selected":""?>>中文</option>
</select>
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
</form>
</div>

<h1>Lichtnet</h1>

<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">

<input type="email" name="email" placeholder="<?=$messages[$lang]["email"]?>" required>
<input type="password" name="password" placeholder="<?=$messages[$lang]["password"]?>" required>

<button><?=$messages[$lang]["login"]?></button>
</form>

<div>
<a href="register.php?from=<?=urlencode($from)?>&lang=<?=$lang?>" class="btn">
<?=$messages[$lang]["switch"]?>
</a>
</div>

<div><?=$msg?></div>

</div>

</body>
</html>