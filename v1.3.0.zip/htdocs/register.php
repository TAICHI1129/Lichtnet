<?php
require "db.php";
session_start();

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

if(empty($_SESSION["csrf"])){
    $_SESSION["csrf"] = bin2hex(random_bytes(32));
}

$messages=[
"ja"=>[
"username"=>"ユーザー名","email"=>"メール","password"=>"パスワード","register"=>"登録","switch"=>"ログインはこちら",
"success"=>"登録成功",
"err_user"=>"ユーザー名は3文字以上",
"err_email"=>"メール形式が不正",
"err_pass"=>"パスワードは6文字以上",
"dup_email"=>"このメールは既に登録されています",
"dup_user"=>"このユーザー名は既に使用されています"
],
"en"=>[
"username"=>"Username","email"=>"Email","password"=>"Password","register"=>"Register","switch"=>"Login",
"success"=>"Registered",
"err_user"=>"Username too short",
"err_email"=>"Invalid email",
"err_pass"=>"Password too short",
"dup_email"=>"Email already used",
"dup_user"=>"Username already used"
]
];

if($_SERVER["REQUEST_METHOD"]==="POST"){

if(!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")){
    die("CSRFエラー");
}

$username=$_POST["username"] ?? "";
$email=$_POST["email"] ?? "";
$password=$_POST["password"] ?? "";

$errors=[];

if(strlen($username)<3) $errors[]=$messages[$lang]["err_user"];
if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $errors[]=$messages[$lang]["err_email"];
if(strlen($password)<6) $errors[]=$messages[$lang]["err_pass"];

if(empty($errors)){

$hash=password_hash($password,PASSWORD_DEFAULT);

try{
$stmt=$pdo->prepare("INSERT INTO users(username,email,password) VALUES (?,?,?)");
$stmt->execute([$username,$email,$hash]);
$msg=$messages[$lang]["success"];

}catch(PDOException $e){

if($e->errorInfo[1]==1062){
if(strpos($e->getMessage(),"email")!==false){
$msg=$messages[$lang]["dup_email"];
}else{
$msg=$messages[$lang]["dup_user"];
}
}else{
$msg="DB error";
}

}

}else{
$msg=implode("<br>",$errors);
}
}
?>
<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
<input type="hidden" name="csrf" value="<?=$_SESSION["csrf"]?>">