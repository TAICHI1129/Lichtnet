<?php
require "db.php";
session_start();

define("SECRET_KEY","LICHTNET_SECRET_KEY");

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

/* CSRF */
if(empty($_SESSION["csrf"])){
    $_SESSION["csrf"] = bin2hex(random_bytes(32));
}

/* リダイレクト許可 */
function is_valid_redirect($url){
    global $pdo;

    if(!filter_var($url, FILTER_VALIDATE_URL)){
        return false;
    }

    $stmt = $pdo->prepare("SELECT * FROM clients WHERE redirect_uri = ?");
    $stmt->execute([$url]);

    return $stmt->fetch() ? true : false;
}

/* トークン */
function create_token($email,$username){
    $payload=[
        "email"=>$email,
        "username"=>$username,
        "iat"=>time(),
        "exp"=>time()+120,
        "nonce"=>bin2hex(random_bytes(8))
    ];
    $b64=base64_encode(json_encode($payload));
    $sign=hash_hmac("sha256",$b64,SECRET_KEY);
    return $b64.".".$sign;
}

/* 多言語 */
$messages=[
"ja"=>[
"email"=>"メール","password"=>"パスワード","login"=>"ログイン","switch"=>"アカウント作成","success"=>"ログイン成功","fail"=>"ログイン失敗"
],
"en"=>[
"email"=>"Email","password"=>"Password","login"=>"Login","switch"=>"Create account","success"=>"Login success","fail"=>"Login failed"
],
"es"=>[
"email"=>"Correo","password"=>"Contraseña","login"=>"Iniciar sesión","switch"=>"Crear cuenta","success"=>"Inicio exitoso","fail"=>"Error de inicio"
],
"zh"=>[
"email"=>"邮箱","password"=>"密码","login"=>"登录","switch"=>"创建账号","success"=>"登录成功","fail"=>"登录失败"
]
];

if($_SERVER["REQUEST_METHOD"]==="POST"){

if(!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")){
    die("CSRFエラー");
}

$email=$_POST["email"] ?? "";
$password=$_POST["password"] ?? "";
$from=$_POST["from"] ?? "";

$stmt=$pdo->prepare("SELECT * FROM users WHERE email=?");
$stmt->execute([$email]);
$user=$stmt->fetch();

if($user && password_verify($password,$user["password"])){

if(!empty($from) && is_valid_redirect($from)){
$token=create_token($email,$user["username"]);
?>

<!DOCTYPE html>
<html>
<body>
<form id="redir" method="POST" action="<?=htmlspecialchars($from)?>">
<input type="hidden" name="token" value="<?=htmlspecialchars($token)?>">
</form>
<script>
document.getElementById('redir').submit();
</script>
</body>
</html>

<?php
exit;
}

$msg=$messages[$lang]["success"];

}else{
$msg=$messages[$lang]["fail"];
}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">

<div class="lang-select">
<form method="get">
<select name="lang" onchange="this.form.submit()">
<option value="ja" <?=$lang=="ja"?"selected":""?>>日本語</option>
<option value="en" <?=$lang=="en"?"selected":""?>>English</option>
<option value="es" <?=$lang=="es"?"selected":""?>>Español</option>
<option value="zh" <?=$lang=="zh"?"selected":""?>>中文</option>
</select>
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
</form>
</div>

<h1>Lichtnet</h1>

<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
<input type="hidden" name="csrf" value="<?=$_SESSION["csrf"]?>">

<input type="email" name="email" placeholder="<?=$messages[$lang]["email"]?>" required>
<input type="password" name="password" placeholder="<?=$messages[$lang]["password"]?>" required>

<button><?=$messages[$lang]["login"]?></button>
</form>

<div>
<a href="register.php?from=<?=urlencode($from)?>&lang=<?=$lang?>" class="btn">
<?=$messages[$lang]["switch"]?>
</a>
</div>

<div><?=htmlspecialchars($msg)?></div>

</div>

</body>
</html>