<?php
require "db.php";
session_start();

$msg = "";

/* ===== CSRF ===== */
if(empty($_SESSION["csrf"])){
    $_SESSION["csrf"] = bin2hex(random_bytes(32));
}

/* ===== 登録処理 ===== */
if($_SERVER["REQUEST_METHOD"]==="POST"){

if(!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")){
    die("CSRFエラー");
}

$url = $_POST["redirect_uri"] ?? "";

/* URLチェック */
if(!filter_var($url, FILTER_VALIDATE_URL)){
    $msg = "URLが不正";
}else{

    /* ホスト取得 */
    $host = parse_url($url, PHP_URL_HOST);

    if(!$host){
        $msg = "URL解析失敗";
    }else{

        /* 連続登録防止 */
        if(isset($_SESSION["last_reg"]) && time() - $_SESSION["last_reg"] < 5){
            $msg = "登録しすぎ";
        }else{

            $_SESSION["last_reg"] = time();

            /* client_id生成 */
            $client_id = bin2hex(random_bytes(16));

            try{

                $stmt=$pdo->prepare(
                    "INSERT INTO clients(client_id, redirect_uri) VALUES (?, ?)"
                );
                $stmt->execute([$client_id, $url]);

                $msg = "登録成功<br>client_id: ".htmlspecialchars($client_id);

            }catch(PDOException $e){

                if($e->errorInfo[1]==1062){
                    $msg = "既に登録されています";
                }else{
                    $msg = "DBエラー";
                }

            }
        }
    }
}
}

/* ===== 一覧取得 ===== */
$stmt = $pdo->query("SELECT * FROM clients ORDER BY id DESC");
$clients = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Clients</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">

<h1>Lichtnet Clients</h1>

<!-- 登録フォーム -->
<form method="POST">
<input type="hidden" name="csrf" value="<?=$_SESSION["csrf"]?>">

<input
type="text"
name="redirect_uri"
placeholder="https://example.com/callback.php"
required
>

<button>登録</button>
</form>

<!-- メッセージ -->
<div><?= $msg ?></div>

<hr>

<h2>登録済みクライアント</h2>

<?php foreach($clients as $c): ?>

<div style="margin-bottom:10px;">
<strong>ID:</strong> <?=htmlspecialchars($c["client_id"])?><br>
<strong>URL:</strong> <?=htmlspecialchars($c["redirect_uri"])?>
</div>

<?php endforeach; ?>

</div>

</body>
</html>