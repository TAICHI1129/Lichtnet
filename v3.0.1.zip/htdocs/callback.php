<?php

$token = $_POST["token"] ?? "";

if(!$token){
    die("トークンなし");
}
?>

<!DOCTYPE html>
<html>
<body>

<form id="redir" method="POST" action="/mypage/index.php">
<input type="hidden" name="token" value="<?=htmlspecialchars($token)?>">
</form>

<script>
document.getElementById('redir').submit();
</script>

</body>
</html>