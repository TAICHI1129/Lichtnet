<?php
require "db.php";
session_start();

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

if(empty($_SESSION["csrf"])){
    $_SESSION["csrf"] = bin2hex(random_bytes(32));
}

$messages=[
"ja"=>[
"username"=>"ユーザー名","email"=>"メール","password"=>"パスワード","register"=>"登録","switch"=>"ログインはこちら",
"success"=>"登録成功",
"err_user"=>"ユーザー名は3文字以上",
"err_email"=>"メール形式が不正",
"err_pass"=>"パスワードは6文字以上",
"dup_email"=>"このメールは既に登録されています",
"dup_user"=>"このユーザー名は既に使用されています"
],
"en"=>[
"username"=>"Username","email"=>"Email","password"=>"Password","register"=>"Register","switch"=>"Login",
"success"=>"Registered",
"err_user"=>"Username too short",
"err_email"=>"Invalid email",
"err_pass"=>"Password too short",
"dup_email"=>"Email already used",
"dup_user"=>"Username already used"
],
"es"=>[
"username"=>"Nombre de usuario","email"=>"Correo","password"=>"Contraseña","register"=>"Crear cuenta","switch"=>"Iniciar sesión",
"success"=>"Registrado","err_user"=>"Nombre demasiado corto","err_email"=>"Correo inválido","err_pass"=>"Contraseña demasiado corta",
"dup_email"=>"Correo ya usado","dup_user"=>"Nombre de usuario ya usado"
],
"zh"=>[
"username"=>"用户名","email"=>"邮箱","password"=>"密码","register"=>"注册","switch"=>"登录",
"success"=>"注册成功","err_user"=>"用户名至少3个字符","err_email"=>"邮箱格式不正确","err_pass"=>"密码至少6个字符",
"dup_email"=>"该邮箱已被使用","dup_user"=>"用户名已被使用"
]
];

if($_SERVER["REQUEST_METHOD"]==="POST"){

    if(!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")){
        die("CSRFエラー");
    }

    $username=$_POST["username"] ?? "";
    $email=$_POST["email"] ?? "";
    $password=$_POST["password"] ?? "";

    $errors=[];

    if(strlen($username)<3) $errors[]=$messages[$lang]["err_user"];
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $errors[]=$messages[$lang]["err_email"];
    if(strlen($password)<6) $errors[]=$messages[$lang]["err_pass"];

    if(empty($errors)){
        $hash=password_hash($password,PASSWORD_DEFAULT);
        try{
            $stmt=$pdo->prepare("INSERT INTO users(username,email,password) VALUES (?,?,?)");
            $stmt->execute([$username,$email,$hash]);
            $msg=$messages[$lang]["success"];
        }catch(PDOException $e){
            if($e->errorInfo[1]==1062){
                if(strpos($e->getMessage(),"email")!==false){
                    $msg=$messages[$lang]["dup_email"];
                }else{
                    $msg=$messages[$lang]["dup_user"];
                }
            }else{
                $msg="DB error";
            }
        }
    }else{
        $msg=implode("<br>",$errors);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Register</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {
    font-family: Arial, sans-serif;
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
}

.card {
    background: #fff;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    width: 400px;
    max-width: 90%;
    box-sizing: border-box;
    text-align: center;
}

input[type="text"],
input[type="email"],
input[type="password"] {
    display: block;
    width: 100%;
    padding: 0.8rem;
    margin-bottom: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 1rem;
}

button, .btn {
    width: 100%;
    padding: 0.8rem;
    font-size: 1rem;
    border: none;
    border-radius: 5px;
    background: #28a745;
    color: #fff;
    cursor: pointer;
    text-align: center;
    display: inline-block;
    text-decoration: none;
}

button:hover, .btn:hover {
    background: #218838;
}

.lang-select {
    text-align: right;
    margin-bottom: 1rem;
}

.lang-select select {
    padding: 0.3rem;
    font-size: 0.9rem;
}

.switch-btn-container {
    margin-top: 1rem;
    display: flex;
    justify-content: center;
}

@media (max-width: 480px) {
    .card {
        padding: 1rem;
    }
    button, .btn {
        font-size: 0.9rem;
        padding: 0.6rem;
    }
}
</style>
</head>
<body>

<div class="card">

<div class="lang-select">
<form method="get">
<select name="lang" onchange="this.form.submit()">
<option value="ja" <?=$lang=="ja"?"selected":""?>>日本語</option>
<option value="en" <?=$lang=="en"?"selected":""?>>English</option>
<option value="es" <?=$lang=="es"?"selected":""?>>Español</option>
<option value="zh" <?=$lang=="zh"?"selected":""?>>中文</option>
</select>
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
</form>
</div>

<h1>Lichtnet</h1>

<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
<input type="hidden" name="csrf" value="<?=$_SESSION["csrf"]?>">

<input type="text" name="username" placeholder="<?=$messages[$lang]["username"]?>" required>
<input type="email" name="email" placeholder="<?=$messages[$lang]["email"]?>" required>
<input type="password" name="password" placeholder="<?=$messages[$lang]["password"]?>" required>

<button style="margin-bottom: 20px;"><?=$messages[$lang]["register"]?></button>
</form>
    

<button onclick="location.href='term.html'">Terms of Use and Privacy Policy</button>
    
<div class="switch-btn-container">
<a href="login.php?from=<?=urlencode($from)?>&lang=<?=$lang?>" class="btn">
<?=$messages[$lang]["switch"]?>
</a>
</div>

<div style="margin-top:1rem; color:red; text-align:center;">
<?=htmlspecialchars($msg)?>
</div>

</div>

</body>
</html>